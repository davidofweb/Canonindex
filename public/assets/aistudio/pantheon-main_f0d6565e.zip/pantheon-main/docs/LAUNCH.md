# PANTHEON: launch plan

The grant needs a token launched through Ascend on Elysium **mainnet**. A testnet launch doesn't count. Ascend goes live on mainnet's first day, and so does PNTH.

## What works today (Elysium testnet)

- **PNTH**, launched through Covenant. Its Covenant holds the creator role: sell fees are burned, and buy fees go to the basket that's paid out to stakers.
- **Covenant**, for anyone: pantheonindex.com/covenant/launch. Two coins are on it so far: PNTH and Covenant Demo (COVD).
- **Staking**: a 3-day unlock, a time bonus up to 1.5×, and a HYPE Passport boost up to 1.25×. Rewards stream over a day.
- **The basket**: live since Oct 15, 20:25 UTC, buying every hour with PNTH's fees and streaming what it buys to stakers. Round 1 (FGK, FLOW, FLOWR, PACT, DAWN) came from DELPHI's data. DELPHI flagged FLOW and FLOWR once they had enough trades to judge, so round 2 (AK, REE, PACT, DAWN, TROLOLO) replaces it on Oct 16 at 12:00 UTC.
- **HYPE Passport**: the service is live and signs Passports that the on-chain registry checks.
- **The Trials vote**: round 3 is open at pantheonindex.com/trials/vote until Oct 17, 10:00 UTC. PNTH stakers pick 3 of 17 coins with free signed ballots: 1 vote for the stake, plus 1 to 3 for a HYPE Passport. Every ballot is public.
- **DELPHI**: scans every Ascend coin twice a day. Claude writes plain-English reports, and every claim links to its transaction: pantheonindex.com/delphi
- **Proof**: 7 of our contracts are verified on the explorer, and the Slither review is in `docs/security/slither.md`. There are 26 contract tests (7 against a copy of live Ascend) and over 300 service tests (Passport, DELPHI, the vote, the keeper and the indexer).

## Day one on mainnet

Each step is a script that is already run on testnet (`script/Deploy.s.sol`):

1. Deploy the HYPE Passport registry. Its attestor is the Passport service. Its guardian is Ascend if they agree to hold it, otherwise a multisig.
2. Deploy the Covenant factory.
3. Launch PNTH through the factory (`TEAM` = the team multisig, `TEAM_BPS=1500`): 1 billion supply, no presale, no team tokens and no dev-buy (a Covenant launch can't have one). Covenant's jobs are set at launch and can never change.
4. Deploy the basket list, the staking contract and the basket vault.
5. Verify every contract on the explorer and publish the addresses on pantheonindex.com/security.
6. Point the site, the Passport service, the keeper and DELPHI at mainnet.
7. The first basket comes about 4 days later: a coin must be 3 days old to enter, and every list waits 24 hours. Until then, buy fees reach stakers as USDC.

## Before mainnet

- An outside review of the five core contracts (Covenant, the basket list, the vault, staking and the Passport registry), paid for from the grant.
- A multisig for the curator, and one for the team's 15% share. The guardian goes to Ascend if they accept.
- The keeper running on its own: it routes PNTH's fees, buys the basket and refreshes Passport boosts.

## Token plan

- 1,000,000,000 PNTH, the Ascend standard. No presale, no team tokens, no dev-buy.
- Every trade pays Ascend's 1% fee: 0.5% to Ascend and 0.5% to PNTH's Covenant.
- Of Covenant's half: **85% does PNTH's jobs** (on buys it goes to the basket for stakers, on sells it's burned) and **15% pays the team**, to a public multisig. That's about 0.075% of each trade. The share is fixed at launch and can never be raised. The testnet version runs at 0%; the setting is `TEAM_BPS` in `script/Deploy.s.sol`.

## After launch

- A Trials round every week on mainnet, with the guardian held by Ascend if they agree.
- Covenant for every Ascend creator: burns, team pay and a share to the basket, with no owner.
- DELPHI as a public good: reports on every Ascend coin, and an open feed other apps can use.
- The HYPE Passport as Elysium's "real HYPE holder" check, for any app.

## What we'd ask of Ascend

- To hold the guardian key that can veto basket lists (it can only stop a list, never add one).
- To confirm the creator share on mainnet: 50% in the code, 25% in the docs.
- Public testing access, so others can trade the coins PANTHEON shows.
