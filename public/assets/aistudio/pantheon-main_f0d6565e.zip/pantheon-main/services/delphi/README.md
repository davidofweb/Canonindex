# DELPHI: the cheat detector for Ascend coins

DELPHI reads every coin launched on Ascend (Elysium testnet) and checks it for three kinds of cheating that charts hide:

| Check | What it looks for | Watch | Flag |
|---|---|---|---|
| Launch bundle | Linked wallets (the creator included) buying in the first 30 s after launch | ≥ 5% of supply | ≥ 15% |
| Wash trading | Fast round trips: the same actor buying and selling the same tokens back within 5 minutes | ≥ 25% of volume | ≥ 50% |
| Hidden concentration | Linked wallets that together hold the circulating supply | ≥ 20% | ≥ 40% |
| …or one wallet (v0.4) | A single wallet, the creator's or anyone's, holding the total supply on its own | ≥ 20% | ≥ 40% |

Each coin gets a verdict, **FLAG**, **WATCH**, **CLEAN** or **NOT ENOUGH DATA**, and a report in which every claim links to the transactions behind it on the explorer. DELPHI reports patterns, not intent: anyone can check its work without trusting it.

Owner: Ayinde. Status and notes: `TASKS.md`. It is **read-only**: public RPC and explorer reads only, no wallet keys, no transactions, nothing to sign. The one secret is the Claude API key for the plain-English explanations, kept outside the repo.

## Why PANTHEON needs it

PANTHEON's index buys a basket of top Ascend coins. A coin that is "top" only because of a bundled launch or wash volume should not be in the basket. DELPHI is the evidence layer for that choice, and it is useful on its own to any Ascend trader.

## How it decides who is "one actor"

Wallets are joined into groups by links, and each link records the transaction(s) that prove it:

| Link | Meaning |
|---|---|
| shared funder | Two wallets got HYPE from the same private wallet |
| funded by | One wallet on the coin sent HYPE to another |
| token pass | Tokens moved directly between two wallets (not through a pool or router) |
| bought for / sold for | One wallet sent a trade that moved another wallet's tokens |
| is creator | The wallet that sent the launch differs from the creator role it named |

**Groups never chain (rules v0.3).** A group is one funder's own star of wallets (plus the funder, if it is on the coin), widened by token passes and trades made between wallets. Two funders' stars are never joined through a wallet both of them paid. Up to v0.2, DELPHI joined every link transitively, and on the farmed testnet that made one "group" out of dozens of unrelated wallets: every coin in PANTHEON's basket was flagged as "35 linked wallets hold 50–93%", chained through 25 different funders, while the two big holders had no direct tie at all.

**A contract's payout is not funding.** HYPE a contract pays out inside a call someone made is most often a sale, a game win or a refund, and a buyer paying sellers says nothing about who controls the sellers. Seen live: an NFT marketplace paying sellers 88% of a round price (one call paid 13 sellers), and the CoinFlip and Splash games paying winners from calls their operators' bots send. Up to v0.2, DELPHI credited all of it to the sender, so a buyer "funded" everyone it bought from. Now a contract's payout counts only when the call was a multi-send (a function whose job is sending HYPE to many addresses, like Disperse's, listed by name in the settings), the sender put HYPE into it, and that contract paid. Then it counts like a plain transfer. A payout in a call made by the coin's own creator or launcher also counts. Anything else links no one, whether it pays one wallet or many.

**Public hubs never link anyone.** The Elysium testnet faucet funded most testers, so linking through it would make everyone one big sybil ring. A funder is a public hub if it is a known faucet or has at least 5,000 transactions, on any network. A coin's own creator or launcher is never a hub on its own coin.

**Testnet and mainnet.** The `NETWORK` setting (`testnet` or `mainnet`; by default it follows the RPC and explorer addresses) picks the profile. On testnet, people fund many wallets from one, run distribution bots and farm, all with free test money, so a wallet that paid HYPE to 5 or more tracked wallets which between them traded 5 or more different coins (not counting coins it launched itself) is treated as public too: it spreads wallets over everything rather than seeding them for one coin. A ring seeds its wallets for the coin it pumps, however many there are, so it still links. On mainnet only the faucet list and the 5,000-transaction rule apply.

**Infrastructure is never a holder or a trader.** That covers the launchpad and everything it names (vault, pool manager, treasuries, ListingDesk), the burn sink, every router seen swapping, and any outside pool (a contract that answers `token0()` and `token1()`). Since rules v0.2 it covers every
other contract too (staking, lockers, faucets): before that, everyone who staked PANTHEON was "one actor"
through the staking contract, and the contract itself counted as a holder with 75% of the supply. A report
notes how much contracts hold once it is 10% or more of the tokens outside the pool, so supply parked in a
contract is said out loud.

## Things we learned from the live chain (2026-10-14)

- Swap amounts are from the **swapper's** side: positive means the swapper received it. The pool manager's source comment says the opposite; we checked against real transfers. A test pins this down: the dev-buy read from the swap equals the `devBuyTokens` that Ascend's own launch event reports, exactly.
- A swap's `sender` is a router. The real trader is the wallet that sent the transaction.
- Coins also trade **outside Ascend**. On the same pool manager, 6 hookless pools hold Ascend coins, and Ascend's own router routes through them. Those trades pay no Ascend fee. DELPHI counts them (marked `outside`) and measures wash volume in tokens, because outside pools can be priced in another currency (one uses native HYPE).
- One arbitrage bot buys on Ascend and sells into a Uniswap-V2-style pair in the same transaction. That pair is detected as a pool and excluded from holders.
- A normal wallet can carry EIP-7702 delegation code (`0xef0100…`) and is still treated as a wallet.
- The public RPC (Conduit) rate-limits heavy log queries with error `-32017`, which viem does not retry. The client paces requests and backs off on that code. The explorer allows about 2,000 requests per 13.5 minutes, and DELPHI stops cleanly before running out.

## Run

```sh
cd services/delphi
npm ci
node scripts/scan.ts                 # all coins → out/index.md, out/scan.json, out/coins/<token>.{md,json}
node scripts/scan.ts --only 0x…      # one coin's report
node scripts/scan.ts --no-explorer   # reuse cached funding data only
```

The first run fills a local cache (`data/delphi.db`, SQLite) with launches, swaps, transfers and explorer answers. Later runs fetch only what is new. If the explorer allowance runs out mid-scan, the run still finishes: the affected coins say so, and none of them can be called CLEAN.

### Plain-English explanations (Claude)

```sh
node scripts/explain.ts            # coins with a finding or a CLEAN verdict, and any with 5+ trades
node scripts/explain.ts --only 0x…  # one coin
node scripts/explain.ts --dry      # which coins it would explain, and the first one's data; no Claude calls
```

Claude (`claude-opus-5-5`) looks into each coin with read-only tools over DELPHI's own data: `coin_report`, `trades`, `holders`, `links`, `clusters`, `wallet` (funding, linked wallets, other coins it touched), `transaction` and `list_coins`. Amounts arrive in human units (tokens, USDC, HYPE) with the transactions behind them. It writes a headline, a short summary, up to six concrete points and its caveats, then calls `submit_report`, which checks the draft before saving it: the verdict must be DELPHI's, and every cited transaction and full address must be part of that coin's data. Errors go back to Claude until the draft passes. Claude explains verdicts and never changes them.

Output: `out/coins/<token>.ai.{json,md}` and `out/explained.md`. A coin is explained again only when its data, the model or the instructions change. The scan's cache is used as is, so explaining never spends the explorer allowance. The first run (9 coins) cost about $1.20.

The key is read from `/var/lib/delphi/keys/anthropic.key` (owner `ayinde`, mode 600; `ANTHROPIC_API_KEY` wins if set). It is never logged or committed. Run the script as `ayinde`.

All settings have working testnet defaults (see `.env.example`). `better-sqlite3` ships prebuilt binaries, so its install script is denied in `package.json` (`allowScripts`).

## Kalos: the same checks on every coin of Elysium's biggest DEX (v2, in progress)

```sh
node scripts/kalos.ts                  # every Kalos coin: a table, then each coin's pools and LPs
node scripts/kalos.ts --only KALOS     # one coin (symbol or address); the read still covers every pool
node scripts/kalos.ts --check 3        # also re-read 3 random trades from the node's receipts
node scripts/kalos.ts --recent 785000  # the recent window for busy coins, in blocks (default ≈ 24 h)
```

Its cache is `DB_PATH` (default `data/kalos-dev.db`; it refuses `data/delphi.db`). The checks run unlinked for now:
funding and links join when this is merged into the main scan.

- **A coin** is any token in a Kalos pool except WHYPE, USDC and mUSDC. Its launch is the first liquidity added
  to any of its pools; its creator is whoever deployed the token. An Ascend coin is not made a Kalos coin: its
  Kalos trades come back separately, as outside trades for its Ascend report.
- **Pools come from the factory's PoolCreated events**, not from Kalos's API (it is only cross-checked; it matched
  all 39 pools on Oct 31).
- **Busy coins are read in two windows**: their launch and the last 24 hours, with balances read from the token
  for everyone seen in them. A coin is busy if its life would hold more than 100,000 transfers (estimated from 5
  samples; KALOS ≈ 1.9 million). The report says so in plain words.
- **LP positions** are replayed from the pools' Mints and Burns and the position manager's NFTs, and valued at the
  current price. Removals of 20% or more of a pool's liquidity are listed with their transactions.

What the live chain showed (2026-10-31):

- **The sign is the other way round from Ascend.** A V3 Swap reports the pool's side: positive means the pool
  received it, so a positive coin amount is a sell. A test pins this against the coin's own Transfer in or out of
  the pool, and `--check` re-reads random trades the same way.
- **Liquidity units mislead.** KALOS's creator holds 99.94% of its main pool's liquidity units, but a narrow range:
  by value at the current price it is 29.75%. Positions valued with V3's tick maths add up to 97-99.99% of most
  pools' balances (the rest is fees not yet collected).
- **Most coins are made by factories.** For 11 of 19, the explorer's creation lookup names no sender, so DELPHI
  finds who sent the creating transaction in that block's call trace.
- **ELYS existed months before Kalos** (block 213,745, 140,000 transfers) and its token contract holds 99.88% of its
  own supply. stKALOS has 24 decimals; checks use shares of supply, so they are unaffected.
- **The explorer's node refuses more than 10,000 logs per query**, with the same code (-32005) as "slow down".
  `BatchRpc` now returns that at once instead of waiting. The node answers the calls of a batch side by side, so
  busy streams are read several ranges at a time, and lookups go six requests at a time.

## PerpMe: the coins behind Kalos's Sniper (in progress)

```sh
node scripts/perpme.ts                  # every PerpMe coin that isn't an xStock: a table
node scripts/perpme.ts --only SHRF      # one coin (symbol or address); the read still covers every launch
node scripts/perpme-check.ts            # 20 random coins against balanceOf and PerpMe's own API
node scripts/perpme-fixtures.ts         # re-record test/fixtures/perpme/ (live)
```

Its cache is `DB_PATH` (default `data/perpme-dev.db`; it refuses `data/delphi.db`). The checks run unlinked for
now: funding and links join when this is merged into the main scan (`collectPerpme` has `collectKalos`'s shape).

- **A coin** is a TokenLaunched on PerpMe's launch factory (the one Kalos's Sniper pins). One transaction makes
  the token, its pool on PerpMe's own Uniswap V3 copy, a single-sided position with the whole supply, sent to
  PerpMe's locker, and the creator's first buy. So the launch is that transaction, the creator is the deployer
  the event names, `devBuyTokens` is its `initialBuyTokens`, and the trades are the V3 Swaps in that one pool.
- **xStocks are left out**, by Kalos's own rule (`kalos-perpme-feed.js`: a name ending in "xStock"): 1,318 of
  the 1,530 launches up to Nov 1, all priced in USDC, 1,263 of them on Oct 28. 212 coins are left: 196 priced in
  HYPE (PerpMe's own WHYPE, not Kalos's), 15 in USDC, 1 in KALOS.
- **Every coin is read in full.** The busiest, PerpMe's own PERPME, has about 53,000 transfers and 52,600 trades;
  a coin past 250,000 transfers gets a note. The first run takes about 5 minutes (mostly the senders of 97,000
  trades), reruns about 20 seconds.
- **The liquidity summary** says whether the launch position's NFT is in PerpMe's locker (read from the position
  manager, and replayed from the events), what share of the pool's positions that is, any positions outside it,
  the pool's reserves, and its HYPE value where the pair is PerpMe's WHYPE.

What the live chain showed (2026-11-01):

- **The sign rule is Kalos's** (a negative coin amount is what the pool paid: a buy). A test pins it on real
  buys and sells with the coin as token0 and as token1, and the creator's buy read from the launch swap equals
  `initialBuyTokens` exactly: 165 of 165 launches with a buy.
- **Holders match the chain exactly.** On 22 coins (20 random plus PERPME and a CHAIR), DELPHI's holders and
  balances equal `balanceOf` at the same block, every address, and so does the creator's share. PerpMe's own
  indexer agrees too once its lag is allowed for: it runs about 8 hours behind the chain.
- **All 212 launch positions sit in PerpMe's locker**; no pool has any other position.
- **Launch protection** (366 parent-chain blocks, about 6 minutes, no wallet above 2% of the supply) is counted in
  HyperEVM blocks: an Elysium block header carries it as `l1BlockNumber`, and the coin answers
  `restrictionsActive()` and `maxWalletAmount()` itself. It starts *after* the creator's own buy: 30 of the 212
  coins opened with a creator buy above 2%, up to 89%.
- **PerpMe has more factories than Kalos pins.** Its API lists 1,888 coins: 1,530 from the current factory,
  268 from the first one (still launching, same events), 87 Uniswap-V4 launches and 4 from test factories.
  Only the current factory is read (`factories` takes more).

## The Trials: from DELPHI's scan to a basket proposal

```sh
node scripts/trials.ts                    # next round: out/trials/round-N.json + round-N.tree.json
node scripts/trials.ts --coins 7 --cap-usdc 100
node scripts/trials.ts --round 1 --count-creator --compare ../../deployments/trials/round-1.json
```

It rebuilds every coin from DELPHI's data and ranks them by **independent trading volume in USDC**: volume
in the coin's Ascend pool, minus trades by the creator (and the launcher, and any wallet DELPHI links to
them), minus wash round trips, counted by the same matching the verdicts use. The top coins share the
basket in proportion to that volume, none above the cap.

**Why not count the creator:** test USDC can be minted for free. Live on Oct 14, round 1's top coin FGK
showed "17,000,170 USDC", but 17M of that was the creator buying their own coin, and other wallets traded
about 170 USDC. Three "CRB" coins had 61,700–594,000 USDC each, and every coin's only trade was a dev-buy by
the same wallet.

**Rules come from the contract.** The coin count, the 20% cap, the 72-hour age and the per-run cap limit
are read from the deployed `ConstituentRegistry` (`MAX_N`, `MAX_WEIGHT_BPS`, `MIN_AGE`, `maxRunCap`). It
also checks: priced in USDC, not PNTH, never a DELPHI FLAG.

**It checks before anyone sends anything.** It dry-runs `propose` as the curator on the live chain. Round 2
was accepted. A list with a too-young coin swapped in was refused with `BadList(4)`, the same rule.

**Anyone can verify a round:**
- The registry stores `keccak256` of the exact bytes of the round file (Micheal's propose script). The
  same scan always gives the same bytes, whatever order the data was read in.
- Round 1's published file hashes exactly to the fingerprint of proposal 0; a test pins this.
- The file's `merkleRoot` is an OpenZeppelin standard Merkle tree with one leaf per coin considered: token,
  pool, verdict, total, wash, creator and independent volume, rank, weight, cap. Any coin's row can be
  proven on its own with the tree file.
- `out/` isn't committed: when a round is proposed, its two files go into `deployments/trials/`.

**It warns about coins the basket won't buy when the round can start** (after the registry's 24-hour wait;
the wait, the 48-hour limit and the 5% band are read from the contracts):
- a price average that will be too old by then;
- a price more than 5% above its average.

After a quiet spell the average lags behind the price. FGK, pumped by its creator, was 43,635% above it. The
curator can leave such a coin out with `--exclude 0xTOKEN:reason` (one per coin), and the reason is recorded in
the round file.

**Rehearsed end to end on a local fork** (`node scripts/fork-trials.ts out/trials/round-N.json`):
- The curator proposes exactly as Micheal's script does. The registry stores the file's fingerprint and the
  exact list, refuses to start it before 24 hours, then starts it.
- The basket buys 0 of 5 coins with no settle trades (all stale), 4 of 5 after one 0.01 USDC trade each, and
  **5 of 5 after small settle trades spread over 6 hours**. Settle the coins a few hours before the round
  starts.

**Micheal's own reader:** a parse-only copy of his `propose` script (the same `vm.parseJson*` calls and
`keccak256(bytes(json))`) reads the round-2 file correctly and gives the same fingerprint as this script.

## DELPHI on X: extra abilities (`X_FEATURES`)

@heyDelph (`scripts/x.ts`) can do more than read DELPHI's chain checks, but only when told to. `X_FEATURES` is a comma list, empty by default:

```sh
X_FEATURES=web,xaccount,wallet,compare node scripts/x.ts --ask "who's the team?" --under '$PNTH is live https://pantheonindex.com' --by Pantheonindex
```

With no feature on she gets exactly the instructions and tools she had before (a test compares her request with one recorded before this existed), and the prompt version stays `x-v5`. Any feature on makes it `x-v6`. An unknown name in the list stops her from starting, so a typo can't leave a feature quietly off.

| Feature | Tool | What it adds | Rough cost per answer that uses it (Sonnet 5.5) |
|---|---|---|---|
| `web` | `web_search`, `web_fetch` (Claude's own server tools, `_20260209` with dynamic filtering) | What a project's site, docs or search results say about its team, supply, tax, locks or roadmap. At most 2 searches and 3 pages (about 4,000 tokens each) per answer. | $0.01 per search plus about $0.01 of tokens per search or page: about $0.03 for one search and one page, about $0.08 at the limits |
| `xaccount` | `x_account` | An X account's age, followers, following, posts, verified, bio and website. Cached 6 hours in `x.db`. The coin post's author usually comes with the mention, so it often needs no extra X call. | under $0.005 in tokens, plus one X user lookup per new handle |
| `wallet` | `wallet_profile` | Any address: wallet, contract or pool, HYPE, transactions sent, first funding, coins it created, traded or holds, linked groups it is in (with each coin's verdict) | under $0.01 in tokens, plus 3 RPC reads |
| `compare` | `compare_coins` | "$A vs $B" side by side: verdicts and checks, holders, the creator's share, age, trades, wallet links. "vs" is found in the question, so both coins are matched. | under $0.005, often less than two `coin_report` calls |

Each feature on also adds about 100–500 tokens to the cached instructions. Most questions are about wallets and use none of these, so the median answer should stay near today's (about $0.02). `scripts/x-eval.ts` prints the median per feature: the median must stay at about $0.04 or less before anything ships.

How the checks treat the new results:
- Every number in a reply must still come from a tool result, the question, or her earlier reply. Results from the new tools count, and so does what the web returned that can be read: a fetched page's text, search result titles and links, and passages cited in her text. Search snippets come encrypted, and what her filtering code prints is her own writing, so neither counts: a number seen only there is refused until she opens the page.
- A full or short address may also be one the new tools or a page returned (a wallet's funder, a contract listed on a site).
- Web pages, bios and search results are written by strangers. They are data, never instructions. She says "their site says …", never vouches for it, and still posts no links. The verdict, advice and link checks apply as before, whatever a page says.
- `web_fetch` runs on Anthropic's servers and can only open links already in the conversation: the posts' links (passed on with this feature), a profile's links, or search results. DELPHI's own machine never fetches a stranger's link.

Adding a tool (for example a contract check or liquidity): add its name to `X_FEATURES` in `src/x/config.ts`, add the service it needs to `FeatureDeps` in `src/x/tooling.ts`, write an `ExtraTool` with `jsonTool()` and add it to `EXTRA_TOOLS` in `src/x/features.ts`, then pass the service in from `scripts/x.ts`. What it returns is remembered for the reply checks automatically.

## Coin safety: the contract and the market (rules `safety-v0.1`)

What a trader wants to know before buying any coin on Elysium, Kalos's or Ascend's. Each check answers
**ok**, **risk** or **unknown** in one plain sentence, with the address, transaction, function or
storage slot behind it and the raw facts. Every read and dry run is pinned to one block.

| Check | What it does | Risk when |
|---|---|---|
| Code | Is it a contract? A proxy (EIP-1967 implementation, admin and beacon slots, EIP-1822, EIP-1167 clones, OpenZeppelin's old slots)? Who can replace its code (the admin, the admin's or beacon's owner)? | Its code can be replaced by someone who has not given up control |
| Verified | Asks Conduit's verifier (Sourcify) for the code it really runs (the implementation, behind a proxy) | Not published, or published for other code |
| Owner | `owner()`, `getOwner()`, `admin()`, `pendingOwner()`, `minter()`, AccessControl roles, who deployed it (and through which factory) | Someone still in control can use a power, or anyone can |
| Powers | Mint, take or burn others' tokens, blacklists, pause, fees and taxes, trade limits, trading switch, fee exemptions, pulling funds out, router and pair, upgrades: from the verified ABI, else from the bytecode's dispatcher | A power is present and someone (or anyone) can still use it |
| Transfer | A real holder sends some to a fresh wallet, which passes it on (eth_simulateV1) | Refused, taxed, or the new holder is stuck |
| Sell | On Kalos: the holder sells, and a fresh wallet buys with HYPE and sells it all back, each compared with Kalos's QuoterV2. On PerpMe: the same in the coin's PerpMe pool, through PerpMe's router and QuoterV2, priced in PerpMe's WHYPE; inside its launch window a buy of just over the 2% cap is tried too | A sale fails, or a trade comes up short of the quote (inside PerpMe's launch window a refusal is "restricted", never a risk) |
| Fake ticker | Its symbol or name against Kalos's approved tokens, WHYPE, USDC, KALOS, stKALOS, PNTH, HYPE and KNTQ, after undoing case, spaces, `$`, invisible characters, accents and Cyrillic, Greek, 0/O and 1/l/I look-alikes | It copies one at another address |

```sh
node scripts/safety.ts 0xTOKEN                           # the report, as JSON
node scripts/safety.ts 0xTOKEN --holder 0x… --amount 100 # test with this holder and 100 whole tokens
node scripts/safety.ts --kalos-all [--out dir]           # every non-base coin in Kalos's list: a table
node scripts/safety-fixtures.ts [--only name]            # re-record the test fixtures (live)
```

**Who can use a power is tested, not guessed.** Each power found is dry-run (`eth_call`) with harmless
arguments from a random wallet, the deployer, its factory, the owner, the minter and any address the
contract names (`creator()`, `launcher()`). A random wallet's call going through means anyone can use it.
On Kalos's list, anyone can mint TA and set its tax. A power with no arguments that every controller is
refused (`enableTrading()` once trading is on) counts as used up.

**A function in the bytecode must be in the dispatcher.** A 4-byte value counts only in a dispatch test
(`PUSH3/4 sel [DUPn] EQ PUSH dest JUMPI`, or XOR / EQ ISZERO for "not this one") whose target is a real
JUMPDEST. Contracts push the same values to call other contracts or to revert with errors. On every plain
contract tried, this matched the explorer's own extraction exactly. When `transfer()` is not found, the
answer is "could not read", never "no powers".

**Taxes are measured against Kalos's own quote** at the same moment, so the pool's fee and price impact
cancel out. A coin that keeps part of every transfer cannot be sold into a Uniswap-V3-style pool at all:
the pool gets less than it was promised and refuses (`IIA`). When no wallet holds the coin (the whole
supply is in the pool), the transfer is tested from the fresh wallet right after its test buy.

**Things we learned from the live chain (2026-10-31)**

- `contracts.conduit.xyz/v2/contract/99801/<address>` is a Sourcify v2 server, the one the explorer asks.
  81 contracts were verified on chain 99801, and only Kalos's USDC proxy among Kalos's 22 tokens (not
  its implementation). A hit counts only if the bytecode it was matched against is the code on chain.
- The explorer's `/api/abi/batch` is not verification: it guesses ABIs from bytecode and a public
  signature database (every function "nonpayable", names like `transfer_attention_tg_invmru_ec11fa8`).
- `/api/contract/creation/<address>` names the transaction and sender only for a wallet's deploy. For a
  contract made by a factory or the launchpad it gives the block, and the block's call trace gives the rest.
- The explorer's node runs `eth_simulateV1` with `validation: false` from any address, unsigned. It caps
  `eth_getLogs` at 10,000 logs, so the holder search walks back in windows that grow from 2,000 blocks.
- WHYPE and Kalos's USDC can be upgraded by Elysium's UpgradeExecutor (the chain owner's contract).

**PerpMe coins** are found from who made them: when PerpMe's coin deployer created the token, its launch
(TokenLaunched in that block) names the pool. PerpMe's router and QuoterV2 are the same code as Kalos's, so
the same dry runs run there. While launch protection is on (the coin's `restrictionsActive()`), the fresh
wallet's buy stays under half the cap, a second fresh wallet asks for just over it (PerpMe's pool then reverts
"TF"), and a refused test trade is called restricted, not a honeypot. A coin priced in USDC or KALOS gets the
holder's sale only: a fresh wallet has no way to pay without HYPE.

**Limits.** Ascend coins trade through Ascend's own router (Infinity-style pools): for them DELPHI tests
a transfer, not a sale. A sale there is not a small adapter: the router is PancakeSwap Infinity's
UniversalRouter (`execute(commands, inputs)` with encoded actions and a full pool key), it pulls tokens through
Permit2 (whose address it doesn't expose), there is no known quoter for its pools to measure a tax against, and
the coins are priced in USDC, which a fresh wallet can't pay with. Role holders are listed only when the
contract can enumerate them; otherwise DELPHI asks about the deployer and the owner only. The holder found is the biggest wallet among recent
recipients: it may be exempt from a tax that hits others (the fresh wallets' tests cover that case on
Kalos). Powers hidden behind functions with no known name in unverified code are counted, not named.

## The live feed for apps (format v1)

`scripts/feed.ts` serves the live feed store (`src/live/store.ts`, written by the watcher) as open JSON on
`127.0.0.1:3210`, which Caddy puts on `pantheonindex.com/api/delphi/`. Kalos's Sniper is the first user. The
endpoints, every field and a working Sniper adapter are in `docs/kalos-adapter.md`; the same is served at
`/v1/format`. Records go out exactly as stored, in an envelope that adds `stale` and `servedAtMs`.

```sh
node scripts/feed.ts                    # serve FEED_DB (default data/feed.db) on 127.0.0.1:${PORT:-3210}
node scripts/feed.ts --seed 500         # a scratch db of 500 fake records (local testing; never touches FEED_DB)
node scripts/disputes.ts                # open disputes (all: every one); text people sent is printed escaped
node scripts/disputes.ts answer 3 upheld "The two wallets share a funder: see the report."
node scripts/feed-load.ts               # load: 5,000 records, batches of 50, 50 at a time, 30 s
node scripts/feed-load.ts --soak        # soak: 10 minutes at a steady 100 requests a second, memory sampled
```

Deploying: `deploy/delphi-feed.service` (systemd) and `deploy/Caddyfile.delphi-feed` (the Caddy block).

## Commands

| Command | What it does |
|---|---|
| `npm test` | Unit tests (vitest). They never touch the network: `test/setup.ts` rejects any `fetch` to a non-loopback host. The explainer's test runs the whole Claude loop against a local fake of the API. |
| `npm run typecheck` | `tsc --noEmit` (strict) |
| `npm run lint` | ESLint with typescript-eslint |
| `npm run check` | All three; run before every commit |

## Layout

| File | Role |
|---|---|
| `src/config.ts` | Settings, infrastructure and hub lists, and **all thresholds** (`RULES`, versioned into every report) |
| `src/types.ts` | Coin, Trade, TokenTransfer, Funding, Link, Finding |
| `src/chain.ts` | RPC: resumable log scans, tx senders, block times, address kinds, coin names, polite fetch |
| `src/explorer.ts` | Blockscout v2: funding history and tx counts, schema-checked, budget-aware |
| `src/store.ts` | SQLite cache: raw logs with a cursor per stream, remembered lookups |
| `src/ingest.ts` | Raw data → one `CoinData` per coin (`assemble` is pure; `collect` fetches) |
| `src/rpc.ts` | Batched JSON-RPC for the explorer's own node (100 calls a request) |
| `src/reads.ts` | Heavy reads over that node: many log streams at once, tx senders, address kinds, view calls, who deployed a contract |
| `src/kalos.ts` | Kalos (Uniswap V3) events → DELPHI's shape: coins, trades, LP positions, liquidity reports (all pure) |
| `src/kalos-collect.ts` | `collectKalos`: fetches every Kalos pool and coin, busy coins in two windows, cached |
| `scripts/kalos.ts` | A standalone look at every Kalos coin, checks run unlinked (run by hand) |
| `src/perpme.ts` | PerpMe launches → DELPHI's shape: launch decoding, xStocks, coins and trades, launch protection, the liquidity summary (all pure) |
| `src/perpme-collect.ts` | `collectPerpme`: fetches every PerpMe launch, its pool's events, LP owner and reserves, cached |
| `src/perpme-api.ts` | PerpMe's dex-sync API and indexer, for cross-checks only |
| `scripts/perpme.ts`, `scripts/perpme-check.ts`, `scripts/perpme-fixtures.ts` | The PerpMe table, the live cross-check, re-recording its fixtures (run by hand) |
| `src/graph.ts` | Hubs, links, clusters (union-find) |
| `src/detect.ts` | The three detectors: pure functions, exact integer maths |
| `src/report.ts` | Verdicts, JSON and markdown reports, index |
| `scripts/scan.ts` | The live scan (run by hand) |
| `scripts/fresh-read.ts` | One fresh read of every Ascend coin, printed as JSON, for Get uploaded's coin checks |
| `src/ai/workspace.ts` | The scan plus cached pools and funding, loaded once for the explainer |
| `src/ai/tools.ts` | The explainer's read-only tools (plain functions, wrapped for Claude) |
| `src/ai/explain.ts` | Instructions, the `submit_report` checks, the Claude loop, markdown |
| `scripts/explain.ts` | Plain-English explanations (run by hand) |
| `src/safety.ts` | Coin safety: the rules (`SAFETY_RULES`), the checks and `checkSafety` |
| `src/bytecode.ts` | Reading code without source: dispatcher selectors, clones, delegations |
| `src/powers.ts` | The powers table: signatures and their selectors |
| `src/honeypot.ts` | Dry runs: holder search, transfer test, Kalos sales and round trips |
| `src/simulate.ts` | `eth_simulateV1` and revert reasons |
| `src/lookalike.ts` | Fake tickers: names compared after undoing look-alike tricks |
| `src/conduit.ts`, `src/kalos-api.ts`, `src/http.ts` | Conduit's verifier and explorer API, Kalos's API, one careful JSON fetch |
| `src/pinned.ts`, `src/tape.ts` | Pinned-block reads; recorded answers for tests |
| `scripts/safety.ts`, `scripts/safety-fixtures.ts` | The safety report (run by hand); re-recording its fixtures |
| `src/live/types.ts`, `src/live/store.ts` | The feed format v1 (zod) and its SQLite store: records, verdict history, disputes |
| `src/live/server.ts` | The feed's HTTP server: endpoints, envelope, ETags, CORS, rate limits, timeouts, disputes |
| `src/live/format.ts` | The feed's own description (`/v1/format`): every endpoint and field, with meanings |
| `src/live/fake.ts` | Fake records for tests, `--seed` and the load test (marked `fake-seed`) |
| `scripts/feed.ts`, `scripts/disputes.ts`, `scripts/feed-load.ts` | Run the feed; answer disputes; load and soak tests |
| `test/` | Synthetic scenarios (`scenario.ts`) and real transactions (`fixtures/live-trades.json`) |

## Safety

- Coin names and symbols are chosen by whoever launched the coin, so they are treated as hostile. Markdown output escapes them (no links, HTML or table breaks) and strips control and bidi characters. File names use the token address only.
- Explorer answers are schema-checked before use. RPC outages are never cached as answers: only a real contract revert is remembered.
- "Nothing found" is not CLEAN unless every check had enough data, including every wallet's funding history.

## Limits (v0)

- Trades on Uniswap-V2-style pairs are not counted as trades yet (their balances are still handled correctly).
- Funding looks at each wallet's earliest 50 incoming transactions and latest 50 contract payments.
- Testnet trading is thin (a few hundred swaps in total), so most coins come out NOT ENOUGH DATA. That answer is honest, not a failure.
- Claude's explanations are checked for verdicts, transactions and addresses, not for every number in the text. Spot checks so far match the data.
