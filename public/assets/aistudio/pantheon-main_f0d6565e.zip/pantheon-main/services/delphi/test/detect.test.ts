import { describe, expect, it } from "vitest";
import type { Address } from "viem";
import { contractHoldings, detectBundle, detectConcentration, detectWash, pct } from "../src/detect.ts";
import { clusters } from "../src/graph.ts";
import { analyze } from "../src/report.ts";
import type { Link } from "../src/types.ts";
import { addr, FAUCET, OUTSIDE_POOL, scenario } from "./scenario.ts";

const WEB = "https://explorer.test";
const F = addr(0xf0); // a private funder (a farmer's wallet)
const wallets = (from: number, n: number) => Array.from({ length: n }, (_, i) => addr(from + i));

/**
 * Eight independent faucet-funded traders, each buying 5M in four buys hours apart: the "normal coin"
 * baseline, with the 32 trades by 8 wallets that rules v0.5 want before judging volume.
 */
function honest(s: ReturnType<typeof scenario>, startSec = 3_600) {
  wallets(0x100, 8).forEach((w, i) => {
    s.fund(w, FAUCET);
    for (let k = 0; k < 4; k++) s.buy(w, 1.25, startSec + i * 3_600 + k * 7_200);
  });
  return s;
}

describe("faucet trap", () => {
  it("never links wallets just because the testnet faucet funded them all", () => {
    const s = scenario();
    wallets(0x100, 6).forEach((w, i) => s.fund(w, FAUCET).buy(w, 30, 1 + i));
    const d = s.build();
    expect(d.links).toEqual([]);
    expect(detectBundle(d).finding).toBeNull();
    expect(detectConcentration(d).finding).toBeNull();
  });

  it("treats any funder with a huge transaction count as public, but a small one as a link", () => {
    const s = scenario();
    wallets(0x100, 3).forEach((w, i) => s.fund(w, F).buy(w, 60, 1 + i));
    expect(s.build(new Map([[F.toLowerCase(), 6_000]])).links).toEqual([]);
    expect(s.build(new Map([[F.toLowerCase(), 40]])).links.map((l) => l.reason)).toEqual(["shared-funder", "shared-funder"]);
  });
});

describe("contracts are not wallets", () => {
  // Eight independent buyers stake most of their tokens in one staking contract (PANTHEON, Oct 2026).
  const STAKING = addr(0x5a);
  const staked = () => {
    const s = honest(scenario());
    s.sell(addr(0x100), 1, 4 * 86_400).sell(addr(0x101), 1, 5 * 86_400);
    wallets(0x100, 8).forEach((w, i) => s.pass(w, STAKING, 3, 6 * 86_400 + i));
    return s;
  };

  it("doesn't link wallets that deposit into the same contract, or count the contract as a holder", () => {
    const d = staked().build(new Map(), [STAKING]);
    expect(d.links).toEqual([]);
    expect(detectConcentration(d).finding).toBeNull();
    const r = analyze(d, { explorerWeb: WEB });
    expect(r.verdict).toBe("CLEAN");
    // 24M of the 38M tokens outside the pool sit in the contract, and the report says so.
    expect(contractHoldings(d)).toEqual({ share: 63.15, top: [{ contract: STAKING.toLowerCase(), pct: 63.15 }] });
    expect(r.notes.join(" ")).toContain("Contracts hold 63.15% of the tokens outside the pool (0x0000…005a 63.15%)");
  });

  it("would call them one actor if the contract were taken for a wallet (the v0.1 mistake)", () => {
    const d = staked().build();
    expect(new Set(d.links.map((l) => l.reason))).toEqual(new Set(["token-pass"]));
    expect(detectConcentration(d).finding?.severity).toBe("flag");
  });

  it("says nothing about contracts that hold little", () => {
    const s = honest(scenario());
    s.pass(addr(0x100), addr(0x5a), 1, 86_400);
    expect(contractHoldings(s.build(new Map(), [addr(0x5a)]))).toBeNull();
  });
});

describe("clean coin", () => {
  it("is CLEAN when every check has data and finds nothing", () => {
    const s = honest(scenario());
    s.sell(addr(0x100), 5, 4 * 86_400).sell(addr(0x101), 2, 5 * 86_400);
    const r = analyze(s.build(), { explorerWeb: WEB });
    expect(r.checks).toEqual({ bundle: "clear", wash: "clear", concentration: "clear" });
    expect(r.verdict).toBe("CLEAN");
  });

  it("is NOT_ENOUGH_DATA, not CLEAN, for a coin almost nobody traded", () => {
    const s = scenario().buy(addr(0x100), 5, 60).buy(addr(0x101), 5, 900);
    const r = analyze(s.build(), { explorerWeb: WEB });
    expect(r.checks).toEqual({ bundle: "clear", wash: "not-enough-data", concentration: "not-enough-data" });
    expect(r.verdict).toBe("NOT_ENOUGH_DATA");
  });
});

describe("launch bundle", () => {
  it("flags linked wallets (and the creator) buying a big share in the first seconds", () => {
    const s = scenario();
    s.fund(s.coin.creator, F).buy(s.coin.creator, 40, 0); // the dev-buy, in the launch transaction
    wallets(0x200, 3).forEach((w, i) => s.fund(w, F).buy(w, 50, 2 + i));
    honest(s);
    const f = detectBundle(s.build()).finding!;
    expect(f.severity).toBe("flag");
    expect(f.metrics).toMatchObject({ linkedWallets: 4, supplyPct: 19 });
    expect(f.summary).toContain("including the creator");
    expect(f.evidence.some((e) => e.what.startsWith("link: shared funder"))).toBe(true);
  });

  it("only watches a smaller linked buy", () => {
    const s = scenario();
    wallets(0x200, 2).forEach((w, i) => s.fund(w, F).buy(w, 30, 5 + i));
    expect(detectBundle(s.build()).finding).toMatchObject({ severity: "watch", metrics: { supplyPct: 6 } });
  });

  it("does not call the creator's disclosed dev-buy alone a bundle", () => {
    const s = scenario();
    s.buy(s.coin.creator, 200, 0).buy(addr(0x100), 5, 3);
    expect(detectBundle(s.build()).finding).toBeNull();
  });

  it("ignores linked buys after the launch window", () => {
    const s = scenario();
    wallets(0x200, 3).forEach((w, i) => s.fund(w, F).buy(w, 100, 120 + i));
    expect(detectBundle(s.build()).finding).toBeNull();
  });

  it("follows bought-for links: one payer sending launch buys to fresh wallets", () => {
    const payer = addr(0x300);
    const s = scenario();
    wallets(0x200, 3).forEach((w, i) => s.buy(w, 60, 1 + i, payer));
    const f = detectBundle(s.build()).finding!;
    expect(f).toMatchObject({ severity: "flag", metrics: { linkedWallets: 3, supplyPct: 18 } });
  });
});

describe("wash trading", () => {
  const testnet = <T extends object>(d: T) => ({ ...d, network: "testnet" as const });

  it("flags a linked pair churning the same tokens within minutes", () => {
    const [a, b] = wallets(0x200, 2) as [`0x${string}`, `0x${string}`];
    const s = honest(scenario(), 100_000);
    for (let k = 0; k < 4; k++) {
      const t = 3_600 * (k + 1);
      s.buy(a, 10, t).pass(a, b, 10, t + 30).sell(b, 10, t + 60);
    }
    const f = detectWash(s.build()).finding!;
    // 80M of the 120M tokens traded are matched round trips, all by the linked pair.
    expect(f).toMatchObject({ severity: "flag", metrics: { washVolumePct: 66.66, roundTripWallets: 2 } });
    expect(f.summary).toContain("by 2 linked wallet(s)");
  });

  it("flags the creator churning its own coin, even alone; on testnet, alone, it's WATCH (makers test their coins)", () => {
    const s = honest(scenario(), 100_000);
    for (let k = 0; k < 3; k++) s.buy(addr(0xc0), 10, 3_600 * (k + 1)).sell(addr(0xc0), 10, 3_600 * (k + 1) + 90);
    expect(detectWash(s.build()).finding).toMatchObject({ severity: "flag", summary: expect.stringContaining("the creator among them") });
    const t = detectWash(testnet(s.build()));
    expect(t.finding?.severity).toBe("watch");
    expect(t.notes?.[0]).toContain("from mainnet this is a flag");
  });

  it("on testnet, says a ring run by a platform's own wallet is the platform testing its coin (PerpMe, Omnia, Nov 1)", () => {
    const platform = addr(0xc0);
    const s = honest(scenario({ creator: platform }), 100_000);
    const bots = wallets(0x200, 3);
    bots.forEach((w) => s.fund(w, platform));
    for (let k = 0; k < 4; k++) bots.forEach((w, i) => s.buy(w, 10, 3_600 * (k + 1) + i * 10).sell(w, 10, 3_600 * (k + 1) + i * 10 + 60));
    const roles = new Map([[platform.toLowerCase(), { kind: "project" as const, says: "owns PerpMe's launch factory: it is PerpMe's own wallet" }]]);
    const t = detectWash({ ...s.build(), network: "testnet", roles });
    expect(t.finding).toBeNull();
    expect(t.notes?.[0]).toMatch(/tied to a wallet that owns PerpMe's launch factory: it is PerpMe's own wallet\. On testnet, most likely the platform testing its own coin: from mainnet this is a flag\.$/);
    expect(detectWash({ ...s.build(), roles }).finding?.severity).toBe("flag");
  });

  it("watches one unlinked wallet churning on mainnet, and only notes it on testnet (rules v0.5)", () => {
    const w = addr(0x200);
    const s = honest(scenario(), 100_000);
    for (let k = 0; k < 3; k++) s.buy(w, 10, 3_600 * (k + 1)).sell(w, 10, 3_600 * (k + 1) + 90);
    expect(detectWash(s.build()).finding).toMatchObject({ severity: "watch", metrics: { washVolumePct: 60, roundTripWallets: 1 } });
    const t = detectWash(testnet(s.build()));
    expect(t.finding).toBeNull();
    expect(t.notes?.[0]).toMatch(/^60% of trading volume is one wallet .* On testnet, most likely bots farming points or trading between pools\.$/);
  });

  it("calls round trips spread over a crowd farming, not one actor faking volume (Kalos, seen Oct 31)", () => {
    const s = honest(scenario(), 100_000);
    wallets(0x300, 20).forEach((w, i) => s.buy(w, 10, 1_000 + i * 600).sell(w, 10, 1_000 + i * 600 + 60));
    const r = detectWash(testnet(s.build()));
    expect(r.finding).toBeNull();
    expect(r.notes?.[0]).toContain("spread over 20 separate wallets or groups: people farming points with test money");
  });

  it("does not call arbitrage between two pools wash trading, in one transaction or two (rules v0.5)", () => {
    const bot = addr(0x400);
    const s = honest(scenario());
    for (let k = 0; k < 5; k++) s.arb(bot, 20, 50_000 + k * 60);
    expect(detectWash(s.build())).toEqual({ enough: true, finding: null });
    const two = honest(scenario());
    for (let k = 0; k < 5; k++) two.buy(bot, 20, 50_000 + k * 300).sell(bot, 20, 50_000 + k * 300 + 60);
    const d = two.build();
    for (const t of d.trades) if (t.side === "sell" && t.holder === bot) Object.assign(t, { pool: OUTSIDE_POOL, outside: true });
    expect(detectWash(d)).toEqual({ enough: true, finding: null });
  });

  it("still sees a buy and sell of the same tokens in the same pool and transaction", () => {
    const bot = addr(0x400);
    const s = honest(scenario());
    for (let k = 0; k < 5; k++) s.arb(bot, 20, 50_000 + k * 60, true);
    // 200M of the 240M tokens traded are matched round trips, by one unlinked wallet: WATCH on mainnet.
    expect(detectWash(s.build()).finding).toMatchObject({ severity: "watch", metrics: { washVolumePct: 83.33, roundTripWallets: 1 } });
  });

  it("does not call a flip days later wash trading", () => {
    const s = honest(scenario());
    s.sell(addr(0x100), 5, 3 * 86_400).sell(addr(0x101), 5, 3 * 86_400 + 60);
    expect(detectWash(s.build())).toEqual({ enough: true, finding: null });
  });

  it("only counts the matched part of a partial round trip", () => {
    const w = addr(0x200);
    const s = honest(scenario(), 100_000).buy(w, 100, 100).sell(w, 10, 160);
    // Matched: 10M of the buy + the 10M sell = 20M of 150M tokens traded.
    expect(detectWash(s.build()).finding).toBeNull();
  });

  it("needs 30 trades before it says anything (rules v0.5)", () => {
    const w = addr(0x200);
    const s = scenario();
    for (let k = 0; k < 8; k++) s.buy(w, 10, 100 + k * 600).sell(w, 10, 130 + k * 600);
    expect(detectWash(s.build())).toEqual({ enough: false, finding: null });
  });
});

describe("one wallet holding the supply (rules v0.4, v0.5)", () => {
  it("watches a creator who kept nearly all of it on mainnet, and notes it on testnet (FGK, seen Oct 31: 98.91%)", () => {
    const s = honest(scenario(), 7_200).buy(addr(0xc0), 900, 5);
    const f = detectConcentration(s.build()).finding!;
    expect(f).toMatchObject({ severity: "watch", metrics: { singleWalletPct: 90, isCreator: "yes" } });
    expect(f.summary).toBe("The creator's wallet holds 90% of the total supply. It can sell at any time.");
    const t = detectConcentration({ ...s.build(), network: "testnet" });
    expect(t.finding).toBeNull();
    expect(t.notes).toEqual(["The creator's wallet holds 90% of the total supply. On testnet, makers often keep their test coins."]);
  });

  it("says who a big wallet is when DELPHI knows (a project's own wallet)", () => {
    const d = { ...honest(scenario(), 7_200).buy(addr(0xc0), 700, 5).build(), network: "testnet" as const };
    const roles = new Map([[addr(0xc0).toLowerCase(), { kind: "project" as const, says: "owns Kalos's factory: it is Kalos's own wallet" }]]);
    expect(detectConcentration({ ...d, roles }).notes).toEqual([
      "The creator's wallet holds 70% of the total supply. It owns Kalos's factory: it is Kalos's own wallet. That is the project's own supply, not a hidden whale; it can still be sold.",
    ]);
  });

  it("watches one wallet with a quarter of the supply, and leaves a 17% dev buy alone", () => {
    expect(detectConcentration(honest(scenario(), 7_200).buy(addr(0x400), 250, 600).build()).finding).toMatchObject({ severity: "watch", metrics: { isCreator: "no" } });
    expect(detectConcentration(honest(scenario(), 7_200).buy(addr(0xc0), 170, 5).build()).finding).toBeNull();
  });

  it("doesn't make one group of everyone a rewards wallet paid (Kalos, seen Oct 31), but still sees the wallet itself", () => {
    const rewards = addr(0xc0);
    const s = honest(scenario(), 7_200).buy(rewards, 700, 5);
    wallets(0x1000, 120).forEach((w, i) => s.pass(rewards, w, 1, 900 + i));
    const f = detectConcentration(s.build()).finding!;
    expect(f).toMatchObject({ severity: "watch", metrics: { isCreator: "yes" } });
    expect(f.summary).toMatch(/^The creator's wallet holds 58% of the total supply\./);
  });

  it("counts what the creator's own wallet holds apart from the wallets linked to it (rules v0.5)", () => {
    const boss = addr(0xc0);
    const small = honest(scenario(), 7_200).buy(boss, 500, 5);
    wallets(0x200, 3).forEach((w, i) => small.fund(w, boss).buy(w, 10, 600 + i * 60));
    // 30M in three side wallets is no hidden whale; the creator's 50% is said as one wallet's share.
    expect(detectConcentration(small.build()).finding).toMatchObject({ severity: "watch", summary: expect.stringMatching(/^The creator's wallet holds 50% of the total supply\./) });
    const big = honest(scenario(), 7_200).buy(boss, 100, 5);
    wallets(0x200, 3).forEach((w, i) => big.fund(w, boss).buy(w, 100, 600 + i * 60));
    expect(detectConcentration(big.build()).finding).toMatchObject({
      severity: "flag",
      summary: "3 wallet(s) linked to the creator hold 68.18% of the tokens held by all 12 holders, on top of what the creator holds.",
    });
  });

  it("still names a linked group that holds more than one wallet's watch share", () => {
    const s = honest(scenario(), 7_200).buy(addr(0x400), 250, 600);
    wallets(0x200, 4).forEach((w, i) => s.fund(w, F).buy(w, 100, 600 + i * 60));
    expect(detectConcentration(s.build()).finding).toMatchObject({ severity: "flag", metrics: { linkedWallets: 4 } });
  });
});

describe("hidden concentration", () => {
  it("flags linked wallets holding most of the circulating tokens", () => {
    const s = honest(scenario(), 7_200);
    wallets(0x200, 4).forEach((w, i) => s.fund(w, F).buy(w, 15, 600 + i * 60));
    const f = detectConcentration(s.build()).finding!;
    // 60M of 100M held by wallets.
    expect(f).toMatchObject({ severity: "flag", metrics: { linkedWallets: 4, circulatingPct: 60, holders: 12 } });
    expect(f.evidence.filter((e) => e.what.includes("holds"))).toHaveLength(4);
  });

  it("sees through tokens passed out to fresh wallets", () => {
    const boss = addr(0x200);
    const s = honest(scenario(), 7_200).buy(boss, 40, 600);
    wallets(0x300, 4).forEach((w, i) => s.pass(boss, w, 10, 700 + i));
    const f = detectConcentration(s.build()).finding!;
    // The boss passed everything out; the four fresh wallets hold 40M of 80M.
    expect(f).toMatchObject({ severity: "flag", metrics: { linkedWallets: 4, circulatingPct: 50 } });
  });

  it("does not count system contracts as holders", () => {
    const s = honest(scenario());
    const d = s.build();
    expect(detectConcentration(d).finding).toBeNull();
    expect(detectConcentration(d).enough).toBe(true);
  });
});

/** Whether v0.2's transitive closure (every link chained) would put all of `ws` in one cluster. */
function chained(links: Link[], ws: Address[]): boolean {
  const next = new Map<string, string[]>();
  for (const l of links) {
    for (const [x, y] of [[l.a, l.b], [l.b, l.a]] as const) next.set(x.toLowerCase(), [...(next.get(x.toLowerCase()) ?? []), y.toLowerCase()]);
  }
  const seen = new Set([ws[0]!.toLowerCase()]);
  const todo = [ws[0]!.toLowerCase()];
  while (todo.length) {
    for (const y of next.get(todo.pop()!) ?? []) {
      if (seen.has(y)) continue;
      seen.add(y);
      todo.push(y);
    }
  }
  return ws.every((w) => seen.has(w.toLowerCase()));
}

describe("farmed testnet (rules v0.3)", () => {
  const [A, B, C] = [addr(0xfa), addr(0xfb), addr(0xfc)];

  it("never chains separate farmers into one group through wallets that several of them paid", () => {
    // Three farmers with two wallets each (7M tokens per wallet), plus two wallets that got HYPE from two
    // farmers each. Seen live on every basket coin: 25 funders chained into "36 linked wallets hold 51%".
    const s = honest(scenario(), 7_200);
    ([[A, 0x200], [B, 0x210], [C, 0x220]] as const).forEach(([f, n], k) => wallets(n, 2).forEach((w, i) => s.fund(w, f).buy(w, 7, 600 + k * 60 + i)));
    const [x, y] = [addr(0x300), addr(0x301)];
    s.fund(x, A).fund(x, B).buy(x, 0.1, 900).fund(y, B).fund(y, C).buy(y, 0.1, 901);
    const d = s.build(new Map(), [], { network: "testnet" });
    const farmers = [...wallets(0x200, 2), ...wallets(0x210, 2), ...wallets(0x220, 2), x, y];
    // v0.2 joined all eight (42.2M of 82.2M, 51%: FLAG). Each farmer's own star holds 17% at most.
    expect(chained(d.links, farmers)).toBe(true);
    expect(detectConcentration(d).finding).toBeNull();
    expect(analyze(d, { explorerWeb: WEB }).verdict).toBe("CLEAN");
    const cl = clusters(d.links);
    expect(cl.get(addr(0x200))).not.toBe(cl.get(addr(0x210)));
    expect(cl.get(addr(0x210))).not.toBe(cl.get(addr(0x220)));
  });

  it("does not let a single weak link (one contract payout between two farmers) join their groups", () => {
    const s = honest(scenario(), 7_200);
    wallets(0x200, 2).forEach((w, i) => s.fund(w, A).buy(w, 15, 600 + i));
    wallets(0x210, 2).forEach((w, i) => s.fund(w, B).buy(w, 15, 700 + i));
    // 0x…200 bought an NFT from 0x…210: the marketplace paid the seller inside the buyer's call.
    s.fund(addr(0x210), addr(0x200), 800, "payout");
    const d = s.build(new Map(), [], { network: "testnet" });
    expect(d.links.some((l) => l.reason === "funded-by")).toBe(false);
    // Each farmer's star holds 30M of 100M: a WATCH, not 60% and a FLAG.
    expect(detectConcentration(d).finding).toMatchObject({ severity: "watch", metrics: { linkedWallets: 2, circulatingPct: 30 } });
  });

  it("does not link the sellers an NFT sweep paid in one transaction", () => {
    // Seen live: one wallet bought NFTs from 13 sellers in one call, and the marketplace paid each of them
    // 88% of the price. Four of the sellers here hold 60% of the coin; the buyer holds some too.
    const buyer = addr(0x5e);
    const s = honest(scenario(), 7_200).buy(buyer, 5, 500);
    const sellers = wallets(0x200, 4);
    s.payout(sellers, buyer, 300);
    sellers.forEach((w, i) => s.buy(w, 15, 600 + i));
    const d = s.build(new Map(), [], { network: "testnet" });
    expect(d.links).toEqual([]);
    expect(detectConcentration(d).finding).toBeNull();
    expect(analyze(d, { explorerWeb: WEB }).verdict).toBe("CLEAN");
  });

  it("does not link the winners a game paid", () => {
    // A coin-flip game's bot settles rounds: each settlement pays several winners from the game's pot.
    const bot = addr(0x6a);
    const s = honest(scenario(), 7_200);
    const winners = wallets(0x200, 5);
    s.payout(winners.slice(0, 3), bot, -7_200).payout(winners.slice(2), bot, -3_600).fund(winners[0]!, bot, -1_800, "payout");
    winners.forEach((w, i) => s.buy(w, 12, 600 + i));
    const d = s.build(new Map(), [], { network: "testnet" });
    expect(d.links).toEqual([]);
    expect(detectConcentration(d).finding).toBeNull();
    // The same payouts at launch are no bundle either.
    const early = scenario();
    early.payout(wallets(0x200, 3), bot);
    wallets(0x200, 3).forEach((w, i) => early.buy(w, 60, 1 + i));
    expect(detectBundle(early.build()).finding).toBeNull();
  });

  it("groups 20 fresh wallets a farmer's main wallet paid through one multi-send, and flags them", () => {
    const main = addr(0xfe);
    const s = honest(scenario(), 7_200);
    const fresh = wallets(0x400, 20);
    s.payout(fresh, main, -3_600, "multisend");
    fresh.forEach((w, i) => s.buy(w, 3, 600 + i));
    // 60M of 100M, in one funder's star: a FLAG on testnet too.
    const f = detectConcentration(s.build(new Map(), [], { network: "testnet" })).finding!;
    expect(f).toMatchObject({ severity: "flag", metrics: { linkedWallets: 20, circulatingPct: 60 } });
    expect(f.evidence.some((e) => e.what.startsWith("link: shared funder"))).toBe(true);
  });

  it("counts any contract payout sent by the coin's own creator", () => {
    const s = honest(scenario(), 7_200);
    const paid = wallets(0x200, 4);
    s.payout(paid, s.coin.creator);
    paid.forEach((w, i) => s.buy(w, 15, 600 + i));
    expect(detectConcentration(s.build()).finding).toMatchObject({ severity: "flag", metrics: { linkedWallets: 4, circulatingPct: 60 } });
  });

  it("treats a distribution bot whose wallets trade many coins as public on testnet, but not on mainnet", () => {
    const bot = addr(0xb0);
    const s = honest(scenario(), 7_200);
    // The bot paid gas to 20 tracked wallets, which traded 6 different coins; four of them hold 60% of this one.
    const paid = wallets(0x400, 20);
    paid.forEach((w) => s.fund(w, bot));
    paid.slice(0, 4).forEach((w, i) => s.buy(w, 15, 600 + i));
    const spread = new Map([[bot.toLowerCase(), { wallets: 20, coins: 6 }]]);
    expect(s.build(new Map(), [], { network: "testnet", payees: spread }).links).toEqual([]);
    expect(detectConcentration(s.build(new Map(), [], { network: "mainnet", payees: spread })).finding?.severity).toBe("flag");
  });

  it("treats a funder whose wallets trade many different coins as a farm on testnet, but still catches a one-coin ring", () => {
    const s = honest(scenario(), 7_200);
    wallets(0x200, 4).forEach((w, i) => s.fund(w, F).buy(w, 15, 600 + i));
    const farm = new Map([[F.toLowerCase(), { wallets: 6, coins: 7 }]]);
    expect(detectConcentration(s.build(new Map(), [], { network: "testnet", payees: farm })).finding).toBeNull();
    // The same four wallets, when their funder seeded them for this coin only: a real ring, FLAG on testnet too.
    expect(detectConcentration(s.build(new Map(), [], { network: "testnet" })).finding).toMatchObject({
      severity: "flag",
      metrics: { linkedWallets: 4, circulatingPct: 60 },
    });
  });

  it("never treats a coin's creator as public on its own coin (a creator funding its snipers)", () => {
    // Seen live: one creator launched 21 test coins and funded the same 16 wallets that sniped each one.
    const s = scenario();
    wallets(0x200, 4).forEach((w, i) => s.fund(w, s.coin.creator).buy(w, 50, 2 + i));
    const busy = new Map([[s.coin.creator.toLowerCase(), { wallets: 30, coins: 12 }]]);
    const f = detectBundle(s.build(new Map([[s.coin.creator.toLowerCase(), 9_000]]), [], { network: "testnet", payees: busy })).finding!;
    expect(f).toMatchObject({ severity: "flag", metrics: { linkedWallets: 4, supplyPct: 20 } });
  });

  it("still flags creator-funded snipers when the creator paid them through any contract", () => {
    const s = scenario();
    s.payout(wallets(0x200, 2), s.coin.creator, -600).fund(addr(0x202), s.coin.creator, -300, "payout");
    wallets(0x200, 3).forEach((w, i) => s.buy(w, 60, 1 + i));
    expect(detectBundle(s.build(new Map(), [], { network: "testnet" })).finding).toMatchObject({
      severity: "flag",
      metrics: { linkedWallets: 3, supplyPct: 18 },
    });
  });

  it("still sees tokens passed out to fresh wallets as one actor on testnet", () => {
    const boss = addr(0x200);
    const s = honest(scenario(), 7_200).buy(boss, 40, 600);
    wallets(0x300, 4).forEach((w, i) => s.pass(boss, w, 10, 700 + i));
    expect(detectConcentration(s.build(new Map(), [], { network: "testnet" })).finding).toMatchObject({
      severity: "flag",
      metrics: { linkedWallets: 4, circulatingPct: 50 },
    });
  });
});

describe("pct", () => {
  it("is exact whole-number maths, rounded down to 2 decimals", () => {
    expect(pct(1n, 3n)).toBe(33.33);
    expect(pct(2n, 3n)).toBe(66.66);
    expect(pct(5n, 0n)).toBe(0);
    expect(pct(10n ** 30n, 10n ** 30n)).toBe(100);
  });
});
